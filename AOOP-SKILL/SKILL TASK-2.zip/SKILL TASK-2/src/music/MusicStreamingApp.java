package music;


interface MusicSource {
 void play();
}


class LocalFile implements MusicSource {
 public void play() {
     System.out.println("Playing music from local files...");
 }
}

class OnlineStreaming implements MusicSource {
 public void play() {
     System.out.println("Streaming music from an online service...");
 }
}

class RadioStation implements MusicSource {
 public void play() {
     System.out.println("Playing music from a radio station...");
 }
}

//Music Player using Bridge Pattern
class MusicPlayer {
 protected MusicSource source;
 
 public MusicPlayer(MusicSource source) {
     this.source = source;
 }
 
 public void playMusic() {
     source.play();
 }
}


class Equalizer extends MusicPlayer {
 private MusicPlayer player;
 
 public Equalizer(MusicPlayer player) {
     super(player.source);
     this.player = player;
 }
 
 public void playMusic() {
     player.playMusic();
     System.out.println("Equalizer applied.");
 }
}

class VolumeControl extends MusicPlayer {
 private MusicPlayer player;
 
 public VolumeControl(MusicPlayer player) {
     super(player.source);
     this.player = player;
 }
 
 public void playMusic() {
     player.playMusic();
     System.out.println("Volume adjusted.");
 }
}


public class MusicStreamingApp {
 public static void main(String[] args) {
     MusicSource[] sources = {new LocalFile(), new OnlineStreaming(), new RadioStation()};
     
     for (MusicSource source : sources) {
         System.out.println("\nNow Playing:");
         MusicPlayer basicPlayer = new MusicPlayer(source);
         MusicPlayer player = new VolumeControl(new Equalizer(basicPlayer));
         player.playMusic();
     }
 }
}
