package emp;

public class EmployeeSortingDemo {
    public static void main(String[] args) {
      
        EmployeeManager manager = new EmployeeManager();

        manager.addEmployee(new Employee(103, "Alice", 50000));
        manager.addEmployee(new Employee(101, "Bob", 60000));
        manager.addEmployee(new Employee(104, "Charlie", 55000));
        manager.addEmployee(new Employee(102, "David", 45000));

        System.out.println("Original Employee List:");
        System.out.println();
        manager.displayEmployees();

        manager.sortById();
        System.out.println("Sorted by ID:");
        manager.displayEmployees();

        manager.sortByName();
        System.out.println("Sorted by Name:");
        manager.displayEmployees();

        manager.sortBySalary();
        System.out.println("Sorted by Salary:");
        manager.displayEmployees();
    }
}
