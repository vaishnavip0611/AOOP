package emp;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class EmployeeManager implements Iterable<Employee> {
    private List<Employee> employees = new ArrayList<>();

    
    public void addEmployee(Employee emp) {
        employees.add(emp);
    }

    
    public void sortById() {
        Collections.sort(employees);
    }

    
    public void sortByName() {
        employees.sort(EmployeeComparator.byName);
    }

    
    public void sortBySalary() {
        employees.sort(EmployeeComparator.bySalary);
    }

   
    @Override
    public Iterator<Employee> iterator() {
        return employees.iterator();
    }

    public void displayEmployees() {
        for (Employee emp : employees) {
            System.out.println(emp);
        }
        System.out.println();
        System.out.println("----------------------");
        System.out.println();
    }
}
