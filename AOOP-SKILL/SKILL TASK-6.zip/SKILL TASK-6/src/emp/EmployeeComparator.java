package emp;

import java.util.Comparator;

public class EmployeeComparator {
    
    
    public static Comparator<Employee> byName = Comparator.comparing(Employee::getName);

    public static Comparator<Employee> bySalary = Comparator.comparingDouble(Employee::getSalary);
}