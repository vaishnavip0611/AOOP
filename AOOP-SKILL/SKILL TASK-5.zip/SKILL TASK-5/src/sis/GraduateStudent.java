package sis;

public class GraduateStudent extends Student {
    private String researchTopic;

    public GraduateStudent(String studentId, String name, String course, String researchTopic) {
        super(studentId, name, course);
        this.researchTopic = researchTopic;
    }

    @Override
    public void displayDetails() {
        super.displayDetails();
        System.out.println("Research Topic: " + researchTopic);
    }
}