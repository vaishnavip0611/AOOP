package sis;


public interface StudentOperations {
 void displayDetails();
}
