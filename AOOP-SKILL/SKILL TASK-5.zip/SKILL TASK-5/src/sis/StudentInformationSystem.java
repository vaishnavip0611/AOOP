package sis;

public class StudentInformationSystem {
    public static void main(String[] args) {
        SISManager sisManager = new SISManager();

        Student student1 = new UndergraduateStudent("S101", "Alice", "Computer Science", 3);
        Student student2 = new GraduateStudent("G202", "Bob", "Data Science", "AI in Healthcare");

        System.out.println("Student Information:");
        System.out.println();
        sisManager.showStudentDetails(student1);
        sisManager.showStudentDetails(student2);
    }
}