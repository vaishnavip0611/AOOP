package sis;


public class UndergraduateStudent extends Student {
 private int semester;

 public UndergraduateStudent(String studentId, String name, String course, int semester) {
     super(studentId, name, course);
     this.semester = semester;
 }

 @Override
 public void displayDetails() {
     super.displayDetails();
     System.out.println("Semester: " + semester);
 }
}
