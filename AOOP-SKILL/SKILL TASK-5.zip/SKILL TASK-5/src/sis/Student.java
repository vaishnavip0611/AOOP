package sis;



public class Student implements StudentOperations {
    protected String studentId;
    protected String name;
    protected String course;

  
    public Student(String studentId, String name, String course) {
        this.studentId = studentId;
        this.name = name;
        this.course = course;
    }

    @Override
    public void displayDetails() {
        System.out.println("ID: " + studentId + ", Name: " + name + ", Course: " + course);
    }
}
