package sis;

public class SISManager {
    public void showStudentDetails(StudentOperations student) {
        student.displayDetails();
        System.out.println("----------------------");
    }
}