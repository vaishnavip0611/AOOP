package employee;

import java.util.*;

public class EmployeeApp {
    public static void main(String[] args) {
        List<Employee> employees = Arrays.asList(
            new Employee("Alice", 50000),
            new Employee("Bob", 60000),
            new Employee("Charlie", 70000),
            new Employee("David", 55000),
            new Employee("Eve", 65000),
            new Employee("Frank", 72000),
            new Employee("Grace", 80000),
            new Employee("Hank", 75000),
            new Employee("Ivy", 68000),
            new Employee("Jack", 57000)
        );


        System.out.println("\nEmployees with salary greater than $60000:");
        employees.stream()
                 .filter(e -> e.getSalary() > 60000)
                 .forEach(System.out::println);

        System.out.println("\nEmployees sorted by salary:");
        employees.stream()
                 .sorted(Comparator.comparing(Employee::getSalary))
                 .forEach(System.out::println);

        Employee highestSalary = employees.stream()
                                          .max(Comparator.comparing(Employee::getSalary))
                                          .orElse(null);
        System.out.println("\nEmployee with Highest Salary: " + highestSalary);

        double averageSalary = employees.stream()
                                        .mapToDouble(Employee::getSalary)
                                        .average()
                                        .orElse(0.0);
        System.out.println("\nAverage Salary: $" + averageSalary);
    }
}
