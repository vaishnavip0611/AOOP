package jdbc;

import java.sql.*;

public class DisplayRecords {
    public static void main(String[] args) {
        String url = "jdbc:postgresql://localhost:5432/student";
        String user = "postgres";
        String password = "root";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM Registration")) {

            System.out.println("ID\tName\t\tAddress\t\tProgram");
            while (rs.next()) {
                System.out.printf("%d\t%s\t\t%s\t\t%s\n",
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getString("address"),
                    rs.getString("program"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
