package thread;

public class SynchronizationDemo {
    public static void main(String[] args) {
        SharedResource sharedResource = new SharedResource();

        WorkerThread thread1 = new WorkerThread(sharedResource, true);
        WorkerThread thread2 = new WorkerThread(sharedResource, false);
        WorkerThread thread3 = new WorkerThread(sharedResource, true);

        
        thread1.start();
        thread2.start();
        thread3.start();

        try {
            thread1.join();
            thread2.join();
            thread3.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("Final count value: " + sharedResource.getCount());
    }
}
