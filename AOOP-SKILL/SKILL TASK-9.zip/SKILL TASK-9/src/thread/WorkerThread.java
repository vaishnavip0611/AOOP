package thread;

public class WorkerThread extends Thread {
    private SharedResource resource;
    private boolean increment;

    public WorkerThread(SharedResource resource, boolean increment) {
        this.resource = resource;
        this.increment = increment;
    }

    @Override
    public void run() {
        for (int i = 0; i < 5; i++) { 
            if (increment) {
                resource.increment();
            } else {
                resource.decrement();
            }
            try {
                Thread.sleep(2000); 
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
