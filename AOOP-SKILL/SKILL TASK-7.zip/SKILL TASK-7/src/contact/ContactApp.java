package contact;

import java.util.Scanner;

public class ContactApp {
    public static void main(String[] args) {
        ContactManager manager = new ContactManager();
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n1. Add Contact  2. Search  3. Remove  4. Display  5. Exit");
            switch (sc.nextInt()) {
                case 1:
                    System.out.print("Enter Name: ");
                    sc.nextLine();
                    String name = sc.nextLine();
                    System.out.print("Enter Phone: ");
                    manager.addContact(name, sc.nextLine());
                    break;
                case 2:
                    System.out.print("Enter Name: ");
                    sc.nextLine();
                    manager.findContact(sc.nextLine());
                    break;
                case 3:
                    System.out.print("Enter Name: ");
                    sc.nextLine();
                    manager.removeContact(sc.nextLine());
                    break;
                case 4:
                    manager.displayContacts();
                    break;
                case 5:
                    System.out.println("Goodbye!");
                    sc.close();
                    return;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
}
