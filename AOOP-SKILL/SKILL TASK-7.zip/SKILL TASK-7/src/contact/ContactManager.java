package contact;

import java.util.*;

public class ContactManager {
    private Set<Contact> contacts = new HashSet<>();
    private Map<String, Contact> contactMap = new HashMap<>();

    public void addContact(String name, String phone) {
        Contact contact = new Contact(name, phone);
        if (contacts.add(contact)) {
            contactMap.put(name.toLowerCase(), contact);
            System.out.println("Contact added.");
        } else {
            System.out.println("Phone number already exists!");
        }
    }

    public void findContact(String name) {
        Contact contact = contactMap.get(name.toLowerCase());
        System.out.println(contact != null ? "Found: " + contact : "Contact not found.");
    }

    public void removeContact(String name) {
        Contact contact = contactMap.remove(name.toLowerCase());
        if (contact != null) {
            contacts.remove(contact);
            System.out.println("Contact removed.");
        } else {
            System.out.println("Contact not found.");
        }
    }

    public void displayContacts() {
        if (contacts.isEmpty()) {
            System.out.println("No contacts available.");
        } else {
            contacts.forEach(System.out::println);
        }
    }
}
