package auction;

public interface Bidder {
    void update(String item, double bidAmount);
}
