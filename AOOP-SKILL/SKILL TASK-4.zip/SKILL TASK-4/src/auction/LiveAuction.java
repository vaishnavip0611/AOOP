package auction;

public class LiveAuction extends Auction {
    private Auctioneer auctioneer;

    public LiveAuction(Auctioneer auctioneer) {
        this.auctioneer = auctioneer;
    }

    @Override
    protected void announceStart() {
        System.out.println("Live auction for " + auctioneer + " has started!");
    }

    @Override
    protected void conductBidding() {
        System.out.println("Bidding is in progress...");
    }

    @Override
    protected void announceWinner() {
        System.out.println("Auction ended! The highest bid is $");
    }
}
