package auction;

import java.util.ArrayList;
import java.util.List;

// Subject Class
public class Auctioneer {
    private List<Bidder> bidders = new ArrayList<>();
    private String item;
    private double highestBid;

    public Auctioneer(String item) {
        this.item = item;
    }

    public void registerBidder(Bidder bidder) {
        bidders.add(bidder);
    }

    public void newBid(double bidAmount) {
        if (bidAmount > highestBid) {
            highestBid = bidAmount;
            notifyBidders();
        }
    }

    private void notifyBidders() {
        for (Bidder bidder : bidders) {
            bidder.update(item, highestBid);
        }
    }
}
