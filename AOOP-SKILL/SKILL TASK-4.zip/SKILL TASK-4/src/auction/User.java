package auction;

public class User implements Bidder {
    private String name;

    public User(String name) {
        this.name = name;
    }

    @Override
    public void update(String item, double bidAmount) {
        System.out.println(name + " has been notified: New highest bid for " + item + " is $" + bidAmount);
    }
}
