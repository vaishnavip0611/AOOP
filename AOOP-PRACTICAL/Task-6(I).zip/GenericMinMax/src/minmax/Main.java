package minmax;

public class Main {

}
