/**
 * 
 */
/**
 * 
 */
module GenericMinMax {
}