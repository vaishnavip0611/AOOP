package game;

public class Game {
    public static void main(String[] args) {
        // Singleton: Manage game state
        GameState gameState = GameState.getInstance();
        gameState.setDifficulty("Easy");
        gameState.setLevel(1);

        System.out.println("Game Level: " + gameState.getLevel());
        System.out.println("Game Difficulty: " + gameState.getDifficulty());

        // Factory Method: Create enemy
        Enemy enemy = EnemyFactory.createEnemy(gameState.getDifficulty());
        enemy.attack();

        // Abstract Factory: Create weapons and power-ups
        GameItem weapon = GameItemFactory.createWeapon(gameState.getDifficulty());
        GameItem powerUp = GameItemFactory.createPowerUp(gameState.getDifficulty());

        weapon.use();
        powerUp.use();
        
        System.out.println("Updated Game State:");
        gameState.setDifficulty("Hard");
        gameState.setLevel(2);
        System.out.println("Game Level: " + gameState.getLevel());
        System.out.println("Game Difficulty: " + gameState.getDifficulty());
        
    }
}
