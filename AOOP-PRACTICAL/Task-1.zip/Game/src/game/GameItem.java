package game;

public class GameItem {
    public void use() {
        System.out.println("Using a generic game item!");
    }
}
