package game;

public class GameItemFactory {
    public static GameItem createWeapon(String difficulty) {
        if (difficulty.equals("Easy")) {
            return new EasyWeapon();
        } else {
            return new HardWeapon();
        }
    }

    public static GameItem createPowerUp(String difficulty) {
        if (difficulty.equals("Easy")) {
            return new Shield();
        } else {
            return new SpeedBoost();
        }
    }
}
