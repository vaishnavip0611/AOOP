package game;

public class SpeedBoost extends GameItem {
    @Override
    public void use() {
        System.out.println("Speed Boost: Increased speed!");
    }
}
