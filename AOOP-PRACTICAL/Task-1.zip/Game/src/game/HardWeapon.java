package game;

public class HardWeapon extends GameItem {
    @Override
    public void use() {
        System.out.println("Hard Weapon: High damage!");
    }
}

