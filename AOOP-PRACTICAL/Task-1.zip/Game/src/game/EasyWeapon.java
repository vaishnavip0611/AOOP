package game;

public class EasyWeapon extends GameItem {
    @Override
    public void use() {
        System.out.println("Easy Weapon: Low damage!");
    }
}
