package game;

public class EnemyFactory {
    public static Enemy createEnemy(String difficulty) {
        if (difficulty.equals("Easy")) {
            return new EasyEnemy();
        } else {
            return new HardEnemy();
        }
    }
}
