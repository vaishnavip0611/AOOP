package game;

public class HardEnemy extends Enemy {
    @Override
    public void attack() {
        System.out.println("Hard Enemy attacks fiercely!");
    }
}

