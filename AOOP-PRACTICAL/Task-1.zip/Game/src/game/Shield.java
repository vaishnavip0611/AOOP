package game;

public class Shield extends GameItem {
    @Override
    public void use() {
        System.out.println("Shield: Blocks damage!");
    }
}
