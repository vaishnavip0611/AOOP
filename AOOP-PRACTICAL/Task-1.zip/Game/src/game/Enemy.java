package game;

public class Enemy {
    public void attack() {
        System.out.println("Enemy attacks!");
    }
}
