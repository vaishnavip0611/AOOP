package pc;

public class Consumer implements Runnable {
    private MessageQueue messageQueue;

    public Consumer(MessageQueue messageQueue) {
        this.messageQueue = messageQueue;
    }

    @Override
    public void run() {
        try {
            for (int i = 1; i <= 5; i++) { 
                messageQueue.consume();
                Thread.sleep(1500); 
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
