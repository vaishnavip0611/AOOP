package pc;

public class MessagingAppMain {
    public static void main(String[] args) {
        MessageQueue messageQueue = new MessageQueue(3); 

        
        Thread producerThread = new Thread(new Producer(messageQueue), "Producer");
        Thread consumerThread = new Thread(new Consumer(messageQueue), "Consumer");

       
        producerThread.start();
        consumerThread.start();

        
        try {
            producerThread.join();
            consumerThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("Messaging Application Completed.");
    }
}
