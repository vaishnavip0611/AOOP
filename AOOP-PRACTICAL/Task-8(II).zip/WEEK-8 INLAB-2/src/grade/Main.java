package grade;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        StudentGrades studentGrades = new StudentGrades();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n1. Add Grade\n2. Get Student Grades\n3. Display All Grades\n4. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter Student ID: ");
                    int studentId = scanner.nextInt();
                    System.out.print("Enter Grade: ");
                    int grade = scanner.nextInt();
                    studentGrades.addGrade(studentId, grade);
                    System.out.println("Grade added successfully.");
                    break;

                case 2:
                    System.out.print("Enter Student ID: ");
                    int id = scanner.nextInt();
                    System.out.println("Grades: " + studentGrades.getGrades(id));
                    break;

                case 3:
                    studentGrades.displayAllGrades();
                    break;

                case 4:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;

                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }
}
