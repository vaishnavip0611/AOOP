package grade;

import java.util.*;

public class StudentGrades {
    private Map<Integer, Set<Integer>> studentGrades;

    public StudentGrades() {
        studentGrades = new HashMap<>();
    }

    // Method to add a grade for a student
    public void addGrade(int studentId, int grade) {
        studentGrades.putIfAbsent(studentId, new HashSet<>());
        studentGrades.get(studentId).add(grade);
    }

    // Method to retrieve grades of a student
    public Set<Integer> getGrades(int studentId) {
        return studentGrades.getOrDefault(studentId, new HashSet<>());
    }

    // Method to display all student grades
    public void displayAllGrades() {
        for (Map.Entry<Integer, Set<Integer>> entry : studentGrades.entrySet()) {
            System.out.println("Student ID: " + entry.getKey() + " Grades: " + entry.getValue());
        }
    }
}
