package jdbc;

import java.sql.*;

public class CreateTable {
    public static void main(String[] args) {
        String url = "jdbc:postgresql://localhost:5432/studentdb";
        String user = "postgres";
        String password = "root";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             Statement stmt = conn.createStatement()) {

            String sql = "CREATE TABLE Registration (" +
                         "id INT PRIMARY KEY, " +
                         "name VARCHAR(50), " +
                         "address VARCHAR(100), " +
                         "program VARCHAR(50))";
            stmt.executeUpdate(sql);
            System.out.println("Table created successfully!");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
