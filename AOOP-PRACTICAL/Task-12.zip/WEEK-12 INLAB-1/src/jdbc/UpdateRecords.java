package jdbc;

import java.sql.*;

public class UpdateRecords {
    public static void main(String[] args) {
        String url = "jdbc:postgresql://localhost:5432/studentdb";
        String user = "postgres";
        String password = "root";

        String sql = "UPDATE Registration SET program = ? WHERE id = ?";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, "AI");
            ps.setInt(2, 100);
            ps.executeUpdate();

            ps.setString(1, "DS");
            ps.setInt(2, 101);
            ps.executeUpdate();

            System.out.println("Records updated!");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
