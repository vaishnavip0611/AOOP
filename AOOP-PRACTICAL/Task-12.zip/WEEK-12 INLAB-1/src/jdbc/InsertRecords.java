package jdbc;

import java.sql.*;

public class InsertRecords {
    public static void main(String[] args) {
        String url = "jdbc:postgresql://localhost:5432/studentdb";
        String user = "postgres";
        String password = "root";

        String sql = "INSERT INTO Registration (id, name, address, program) VALUES (?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            Object[][] data = {
                {100, "Alice", "Delhi", "CSE"},
                {101, "Bob", "Mumbai", "IT"},
                {102, "Charlie", "Chennai", "ECE"},
                {103, "Diana", "Kolkata", "EEE"}
            };

            for (Object[] student : data) {
                ps.setInt(1, (int) student[0]);
                ps.setString(2, (String) student[1]);
                ps.setString(3, (String) student[2]);
                ps.setString(4, (String) student[3]);
                ps.executeUpdate();
            }

            System.out.println("Records inserted successfully!");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
