package logger;

public class Client {
    public static void main(String[] args) {
        // Create handlers
        LogHandler infoHandler = new InfoHandler();
        LogHandler debugHandler = new DebugHandler();
        LogHandler errorHandler = new ErrorHandler();

        // Set up the chain of responsibility
        infoHandler.setNext(debugHandler);
        debugHandler.setNext(errorHandler);

        // Create logger and commands
        Logger logger = new Logger();

        logger.addCommand(new LogCommand(LogLevel.INFO, infoHandler));
        logger.addCommand(new LogCommand(LogLevel.DEBUG, infoHandler));
        logger.addCommand(new LogCommand(LogLevel.ERROR, infoHandler));

        // Process log messages
        logger.processCommands();
    }
}
