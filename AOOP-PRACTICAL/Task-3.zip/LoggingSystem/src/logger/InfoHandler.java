package logger;

public class InfoHandler extends LogHandler {
    @Override
    public void handleRequest(LogLevel level, String message) {
        if (level == LogLevel.INFO) {
            System.out.println("INFO: " + message);
        } else if (next != null) {
            next.handleRequest(level, message);
        }
    }
}
