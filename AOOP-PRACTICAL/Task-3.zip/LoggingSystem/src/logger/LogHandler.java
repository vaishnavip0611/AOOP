package logger;

public abstract class LogHandler {
    protected LogHandler next;

    public void setNext(LogHandler next) {
        this.next = next;
    }

    public abstract void handleRequest(LogLevel level, String message);
}
