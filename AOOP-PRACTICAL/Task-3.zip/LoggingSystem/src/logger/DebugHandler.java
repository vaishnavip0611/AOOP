package logger;

public class DebugHandler extends LogHandler {
    @Override
    public void handleRequest(LogLevel level, String message) {
        if (level == LogLevel.DEBUG) {
            System.out.println("DEBUG: " + message);
        } else if (next != null) {
            next.handleRequest(level, message);
        }
    }
}
