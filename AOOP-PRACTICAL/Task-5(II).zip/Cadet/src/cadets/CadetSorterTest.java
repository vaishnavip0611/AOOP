package cadets;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;


public class CadetSorterTest {
    @Test
    public void testCadetSorting() {
        CadetSorter sorter = new CadetSorter();
        List<String> cadets = Arrays.asList("John", "Alice", "Bob", "Alice", "John");
        List<String> sortedCadets = Arrays.asList("Alice", "Alice", "Bob", "John", "John");
        sorter.sortCadets(cadets);
        assertTrue(cadets.equals(sortedCadets), "The list is not sorted correctly.");
    }
}