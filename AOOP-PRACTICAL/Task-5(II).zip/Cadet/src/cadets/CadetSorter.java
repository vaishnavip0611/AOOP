package cadets;

import java.util.List;
import java.util.Collections;

public class CadetSorter {
    public List<String> sortCadets(List<String> cadets) {
        Collections.sort(cadets);
        return cadets;
    }
}
