package company;

import java.util.*;

public class Main {
 public static void main(String[] args) {
     List<Employee> employees = Arrays.asList(
         new Employee("Alice", 30, "HR", 60000),
         new Employee("Bob", 28, "IT", 70000),
         new Employee("Charlie", 35, "Finance", 80000),
         new Employee("David", 40, "IT", 75000),
         new Employee("Emma", 27, "HR", 50000)
     );

    
     System.out.println("Employees in IT department:");
     employees.stream()
              .filter(e -> e.department.equals("IT"))
              .forEach(System.out::println);

    
     System.out.println("\nEmployees sorted by name:");
     employees.stream()
              .sorted(Comparator.comparing(e -> e.name))
              .forEach(System.out::println);

     
     Employee highestPaid = employees.stream()
                                     .max(Comparator.comparingDouble(e -> e.salary))
                                     .orElse(null);
     System.out.println("\nEmployee with the highest salary:");
     System.out.println(highestPaid);

     
     double avgSalary = employees.stream()
                                 .mapToDouble(e -> e.salary)
                                 .average()
                                 .orElse(0.0);
     System.out.println("\nAverage Salary: " + avgSalary);
 }
}
