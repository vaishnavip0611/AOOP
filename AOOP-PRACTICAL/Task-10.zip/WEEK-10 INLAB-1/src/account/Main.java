package account;

public class Main {
    public static void main(String[] args) {
        
        Account account = new Account(12345, 1000);

       
        Thread t1 = new Thread(new TransactionRunnable(account, 500, true), "Runnable-1");
        Thread t2 = new Thread(new TransactionRunnable(account, 300, false), "Runnable-2");

        
        TransactionThread t3 = new TransactionThread(account, 200, true);
        TransactionThread t4 = new TransactionThread(account, 700, false);
        
        t3.setName("Thread-3");
        t4.setName("Thread-4");

        
        t1.start();
        t2.start();
        t3.start();
        t4.start();

        
        try {
            t1.join();
            t2.join();
            t3.join();
            t4.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

       
        System.out.println("\nFinal Account Balance: $" + account.getBalance());
    }
}