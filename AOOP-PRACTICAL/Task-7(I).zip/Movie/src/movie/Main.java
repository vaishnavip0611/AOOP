package movie;

import java.util.*;
public class Main {
	public static void main(String[]args) {
		List<Movie>movies=new ArrayList<>();
		movies.add(new Movie("Inception", 8.8, 2010));
        movies.add(new Movie("Interstellar", 8.6, 2014));
        movies.add(new Movie("The Dark Knight", 9.0, 2008));
        movies.add(new Movie("The Prestige", 8.5, 2006));
		Collections.sort(movies);
		System.out.println("Movies sorted by Year:");
		for (Movie movie : movies) {
            System.out.println(movie.getname() + " (" + movie.getyear() + ") - Rating: " + movie.getrating());
        }
	}
}
