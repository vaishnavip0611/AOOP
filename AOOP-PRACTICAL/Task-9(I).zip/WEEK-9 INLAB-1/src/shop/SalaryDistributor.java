package shop;


import java.util.*;
import java.util.function.Predicate;

public class SalaryDistributor {
 public static void distributeSalaries(List<Employee> employees) {
     
     employees.sort((e1, e2) -> Integer.compare(e2.getExperience(), e1.getExperience()));

     
     Predicate<Employee> bonusEligibility = emp -> emp.getExperience() > 2;


     for (Employee emp : employees) {
         if (bonusEligibility.test(emp)) {
             emp.setBonus(emp.getSalary() * 0.10); 
         }
     }

     
     System.out.println("Final Salary Distribution:");
     for (Employee emp : employees) {
         System.out.println(emp);
     }
 }
}
