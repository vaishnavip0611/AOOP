package shop;


public class Employee {
 private String name;
 private int age;
 private int experience;
 private double salary;
 private double bonus;

 public Employee(String name, int age, int experience, double salary) {
     this.name = name;
     this.age = age;
     this.experience = experience;
     this.salary = salary;
     this.bonus = 0.0; // Default bonus
 }

 public String getName() {
     return name;
 }

 public int getExperience() {
     return experience;
 }

 public double getSalary() {
     return salary;
 }

 public void setBonus(double bonus) {
     this.bonus = bonus;
 }

 public double getTotalSalary() {
     return salary + bonus;
 }

 @Override
 public String toString() {
     return "Employee: " + name + ", Age: " + age + ", Experience: " + experience + 
            " years, Salary: $" + salary + ", Bonus: $" + bonus + 
            ", Total Salary: $" + getTotalSalary();
 }
}
