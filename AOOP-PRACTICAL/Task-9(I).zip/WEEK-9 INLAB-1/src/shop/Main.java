package shop;


import java.util.*;

public class Main {
 public static void main(String[] args) {
     List<Employee> employees = new ArrayList<>();
     employees.add(new Employee("Employee1", 30, 5, 50000));
     employees.add(new Employee("Employee2", 28, 4, 45000));
     employees.add(new Employee("Employee3", 26, 3, 40000));
     employees.add(new Employee("Employee4", 24, 1, 35000));
     employees.add(new Employee("Employee5", 22, 0, 30000));

     
     SalaryDistributor.distributeSalaries(employees);
 }
}
