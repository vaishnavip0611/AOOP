package contact;

public class Main {
    public static void main(String[] args) {
        ContactManager cm = new ContactManager();

        
        cm.addContact("Alice", "123-456-7890");
        cm.addContact("Bob", "987-654-3210");
        cm.addContact("Charlie", "555-666-7777");

        
        System.out.println("Bob's Phone Number: " + cm.getContact("Bob"));

        
        cm.removeContact("Alice");

        
        cm.listContacts();
    }
}
