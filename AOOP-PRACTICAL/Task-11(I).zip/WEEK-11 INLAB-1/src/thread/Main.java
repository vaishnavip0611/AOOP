package thread;

public class Main {
    public static void main(String[] args) {
        BankAccount sharedAccount = new BankAccount(1000.0);

        Thread user1 = new BankTransactionThread(sharedAccount, true, 500);   // Deposit
        Thread user2 = new BankTransactionThread(sharedAccount, false, 300);  // Withdraw
        Thread user3 = new BankTransactionThread(sharedAccount, false, 800);  // Withdraw
        Thread user4 = new BankTransactionThread(sharedAccount, true, 200);   // Deposit

        user1.setName("User1");
        user2.setName("User2");
        user3.setName("User3");
        user4.setName("User4");

        user1.start();
        user2.start();
        user3.start();
        user4.start();
    }
}
