/**
 * 
 */
/**
 * 
 */
module MusicApplication {
}