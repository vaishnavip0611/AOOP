package music;

public class VolumeControlFeature implements MusicFeatures {
    private MusicPlayback musicPlayback;

    public VolumeControlFeature(MusicPlayback musicPlayback) {
        this.musicPlayback = musicPlayback;
    }

    @Override
    public void applyFeatures() {
        musicPlayback.playMusic();
        System.out.println("Adjusting volume.");
    }
}
