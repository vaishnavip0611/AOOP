package music;

public class OnlineMusicPlayer implements MusicPlayer {
    private String songName;

    public OnlineMusicPlayer(String songName) {
        this.songName = songName;
    }

    @Override
    public void play() {
        System.out.println("Playing online song: " + songName);
    }

    @Override
    public void pause() {
        System.out.println("Pausing online song playback.");
    }

    @Override
    public void stop() {
        System.out.println("Stopping online song playback.");
    }
}
