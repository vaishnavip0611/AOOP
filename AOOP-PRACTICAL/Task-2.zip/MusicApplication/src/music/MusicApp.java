package music;

public class MusicApp {
    public static void main(String[] args) {
        // Creating different music players
        MusicPlayer localPlayer = new LocalFilePlayer("song.mp3");
        MusicPlayer onlinePlayer = new OnlineMusicPlayer("Song Title");
        MusicPlayer radioPlayer = new RadioPlayer("FM");

        // Wrapping them with the adapter
        MusicPlayer localAdapter = new MusicSourceAdapter(localPlayer);
        MusicPlayer onlineAdapter = new MusicSourceAdapter(onlinePlayer);
        MusicPlayer radioAdapter = new MusicSourceAdapter(radioPlayer);

        // Creating standard playback for each source
        MusicPlayback localPlayback = new StandardPlayback(localAdapter);
        MusicPlayback onlinePlayback = new StandardPlayback(onlineAdapter);
        MusicPlayback radioPlayback = new StandardPlayback(radioAdapter);

        // Adding volume control feature
        MusicFeatures localWithVolume = new VolumeControlFeature(localPlayback);
        MusicFeatures onlineWithVolume = new VolumeControlFeature(onlinePlayback);
        MusicFeatures radioWithVolume = new VolumeControlFeature(radioPlayback);

        // Playing, pausing, and stopping music with volume control
        System.out.println("Local Player with Volume Control:");
        localWithVolume.applyFeatures();
        localPlayback.pauseMusic();
        localPlayback.stopMusic();

        System.out.println("\nOnline Player with Volume Control:");
        onlineWithVolume.applyFeatures();
        onlinePlayback.pauseMusic();
        onlinePlayback.stopMusic();

        System.out.println("\nRadio Player with Volume Control:");
        radioWithVolume.applyFeatures();
        radioPlayback.pauseMusic();
        radioPlayback.stopMusic();
    }
}
