package music;

public interface MusicFeatures {
    void applyFeatures();
}
