package music;

public interface MusicPlayer {
    void play();
    void pause();
    void stop();
}
