package music;

public class RadioPlayer implements MusicPlayer {
    private String stationName;

    public RadioPlayer(String stationName) {
        this.stationName = stationName;
    }

    @Override
    public void play() {
        System.out.println("Playing radio station: " + stationName);
    }

    @Override
    public void pause() {
        System.out.println("Pausing radio station playback.");
    }

    @Override
    public void stop() {
        System.out.println("Stopping radio station playback.");
    }
}
