package music;

public class StandardPlayback implements MusicPlayback {
    private MusicPlayer musicPlayer;

    public StandardPlayback(MusicPlayer musicPlayer) {
        this.musicPlayer = musicPlayer;
    }

    @Override
    public void playMusic() {
        musicPlayer.play();
    }

    @Override
    public void pauseMusic() {
        musicPlayer.pause();
    }

    @Override
    public void stopMusic() {
        musicPlayer.stop();
    }
}
