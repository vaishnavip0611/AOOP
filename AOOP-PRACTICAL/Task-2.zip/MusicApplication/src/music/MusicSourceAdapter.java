package music;

public class MusicSourceAdapter implements MusicPlayer {
    private MusicPlayer musicPlayer;

    public MusicSourceAdapter(MusicPlayer musicPlayer) {
        this.musicPlayer = musicPlayer;
    }

    @Override
    public void play() {
        musicPlayer.play();
    }

    @Override
    public void pause() {
        musicPlayer.pause();
    }

    @Override
    public void stop() {
        musicPlayer.stop();
    }
}
