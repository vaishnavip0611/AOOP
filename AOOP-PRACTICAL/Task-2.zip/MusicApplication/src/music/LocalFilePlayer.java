package music;

public class LocalFilePlayer implements MusicPlayer {
    private String fileName;

    public LocalFilePlayer(String fileName) {
        this.fileName = fileName;
    }

    @Override
    public void play() {
        System.out.println("Playing from local file: " + fileName);
    }

    @Override
    public void pause() {
        System.out.println("Pausing local file playback.");
    }

    @Override
    public void stop() {
        System.out.println("Stopping local file playback.");
    }
}
