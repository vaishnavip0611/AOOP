package music;

public interface MusicPlayback {
    void playMusic();
    void pauseMusic();
    void stopMusic();
}
