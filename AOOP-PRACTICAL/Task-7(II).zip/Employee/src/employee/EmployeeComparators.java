package employee;

import java.util.Comparator;

class SortBySalaryAsc implements Comparator<Employee> {
    @Override
    public int compare(Employee e1, Employee e2) {
        return Double.compare(e1.salary, e2.salary);
    }
}

class SortBySalaryDesc implements Comparator<Employee> {
    @Override
    public int compare(Employee e1, Employee e2) {
        return Double.compare(e2.salary, e1.salary);
    }
}

class SortByName implements Comparator<Employee> {
    @Override
    public int compare(Employee e1, Employee e2) {
        return e1.name.compareTo(e2.name);
    }
}

class SortByDepartment implements Comparator<Employee> {
    @Override
    public int compare(Employee e1, Employee e2) {
        return e1.department.compareTo(e2.department);
    }
}
