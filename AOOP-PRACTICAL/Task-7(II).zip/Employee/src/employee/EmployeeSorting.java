package employee;

import java.util.*;

public class EmployeeSorting {
    public static void main(String[] args) {
        // Creating a list of employees
        List<Employee> employees = new ArrayList<>();
        employees.add(new Employee(101, "Alice", "HR", 50000));
        employees.add(new Employee(102, "Bob", "IT", 60000));
        employees.add(new Employee(103, "Charlie", "Finance", 55000));
        // Sorting by Salary (Ascending)
        Collections.sort(employees, new SortBySalaryAsc());
        System.out.println("Sorted by Salary (Ascending):");
        for (Employee e : employees) {
            System.out.println(e);
        }
        
        // Sorting by Salary (Descending)
        Collections.sort(employees, new SortBySalaryDesc());
        System.out.println("\nSorted by Salary (Descending):");
        for (Employee e : employees) {
            System.out.println(e);
        }
        
        // Sorting by Name (Alphabetical Order)
        Collections.sort(employees, new SortByName());
        System.out.println("\nSorted by Name (Alphabetical Order):");
        for (Employee e : employees) {
            System.out.println(e);
        }
        
        // Sorting by Department (Alphabetical Order)
        Collections.sort(employees, new SortByDepartment());
        System.out.println("\nSorted by Department (Alphabetical Order):");
        for (Employee e : employees) {
            System.out.println(e);
        }
    }
}
