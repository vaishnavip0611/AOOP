package student;

public interface EnrollmentManagement {
    void enrollStudent(String studentId, String courseId); 
    void unenrollStudent(String studentId, String courseId); 
}
