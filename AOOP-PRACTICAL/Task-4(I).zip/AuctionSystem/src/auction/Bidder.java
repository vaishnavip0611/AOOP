package auction;

public interface Bidder {
    void update(String message); // Method to receive notifications
}
